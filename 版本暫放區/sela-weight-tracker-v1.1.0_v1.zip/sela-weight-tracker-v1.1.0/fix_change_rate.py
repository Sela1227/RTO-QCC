"""修復體重變化率數據

此腳本會重新計算所有體重記錄的 change_rate
確保下降為負數、上升為正數

執行方式：python fix_change_rate.py
"""
import os
import sys

# 設定路徑
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.models.database import Database


def preview_issues():
    """預覽需要修正的記錄"""
    db = Database()
    
    treatments = db.fetch_all("SELECT id, baseline_weight FROM treatments")
    print(f"找到 {len(treatments)} 個療程\n")
    
    issues = []
    
    for t in treatments:
        treatment_id = t["id"]
        baseline = t["baseline_weight"]
        
        if not baseline or baseline <= 0:
            continue
        
        records = db.fetch_all(
            """SELECT wr.id, wr.weight, wr.change_rate, wr.measure_date,
                      p.medical_id, p.name
               FROM weight_records wr
               JOIN treatments t ON wr.treatment_id = t.id
               JOIN patients p ON t.patient_id = p.id
               WHERE wr.treatment_id = ?
               ORDER BY wr.measure_date""",
            (treatment_id,)
        )
        
        for r in records:
            weight = r["weight"]
            old_rate = r["change_rate"]
            
            # 正確計算
            new_rate = round((weight - baseline) / baseline * 100, 2)
            
            # 如果差異超過 0.1%，視為需要修正
            if old_rate is not None and abs(old_rate - new_rate) > 0.1:
                issues.append({
                    "medical_id": r["medical_id"],
                    "name": r["name"],
                    "date": r["measure_date"],
                    "baseline": baseline,
                    "weight": weight,
                    "old_rate": old_rate,
                    "new_rate": new_rate,
                })
    
    return issues


def fix_change_rates():
    """重新計算所有體重記錄的 change_rate"""
    db = Database()
    
    treatments = db.fetch_all("SELECT id, baseline_weight FROM treatments")
    print(f"找到 {len(treatments)} 個療程")
    
    fixed_count = 0
    
    for t in treatments:
        treatment_id = t["id"]
        baseline = t["baseline_weight"]
        
        if not baseline or baseline <= 0:
            continue
        
        records = db.fetch_all(
            "SELECT id, weight, change_rate FROM weight_records WHERE treatment_id = ?",
            (treatment_id,)
        )
        
        for r in records:
            record_id = r["id"]
            weight = r["weight"]
            old_rate = r["change_rate"]
            
            # 正確計算：(目前 - 基準) / 基準 × 100
            new_rate = round((weight - baseline) / baseline * 100, 2)
            
            # 重新判斷 alert_level
            if new_rate <= -5:
                new_alert = "nutrition"
            elif new_rate <= -3:
                new_alert = "sdm"
            else:
                new_alert = "none"
            
            # 更新
            db.execute(
                "UPDATE weight_records SET change_rate = ?, alert_level = ? WHERE id = ?",
                (new_rate, new_alert, record_id)
            )
            
            if old_rate != new_rate:
                print(f"  修正: {weight}kg, {old_rate}% -> {new_rate}%")
                fixed_count += 1
    
    print(f"\n完成！共修正 {fixed_count} 筆記錄")


if __name__ == "__main__":
    print("="*50)
    print("體重變化率修復工具")
    print("="*50)
    print()
    print("計算公式：(目前體重 - 基準體重) / 基準體重 × 100%")
    print("  - 體重下降 → 負數（如 -3.5%）")
    print("  - 體重上升 → 正數（如 +2.0%）")
    print()
    
    # 先預覽
    print("正在檢查數據...")
    issues = preview_issues()
    
    if not issues:
        print("\n✅ 所有數據正確，無需修正！")
    else:
        print(f"\n⚠️  發現 {len(issues)} 筆需要修正的記錄：\n")
        print(f"{'病歷號':<10} {'姓名':<8} {'日期':<12} {'基準':<8} {'體重':<8} {'舊值':<8} {'新值':<8}")
        print("-" * 70)
        for issue in issues[:20]:  # 最多顯示 20 筆
            print(f"{issue['medical_id']:<10} {issue['name']:<8} {issue['date']:<12} "
                  f"{issue['baseline']:<8.1f} {issue['weight']:<8.1f} "
                  f"{issue['old_rate']:>+7.1f}% {issue['new_rate']:>+7.1f}%")
        
        if len(issues) > 20:
            print(f"... 還有 {len(issues) - 20} 筆")
        
        print()
        confirm = input("確定要修正這些記錄嗎？(y/N): ").strip().lower()
        if confirm == 'y':
            fix_change_rates()
        else:
            print("已取消")

